----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-06-16 9:34 am CDT
----------------------------------------------------------------

-------------------  ----------------------------------------------------------------------  ------------------------
GDP                  Gross Domestic Product, Billions of Dollars, Quarterly, Seasonally      Data Updated: 2026-05-28
                     Adjusted Annual Rate
GDPC1                Real Gross Domestic Product, Billions of Chained 2017 Dollars,          Data Updated: 2026-05-28
                     Quarterly, Seasonally Adjusted Annual Rate
FPCPITOTLZGUSA       Inflation, consumer prices for the United States, Percent, Annual, Not  Data Updated: 2025-04-16
                     Seasonally Adjusted
CPIAUCSL             Consumer Price Index for All Urban Consumers: All Items in U.S. City    Data Updated: 2026-06-10
                     Average, Index 1982-1984=100, Monthly, Seasonally Adjusted
UNRATE               Unemployment Rate, Percent, Monthly, Seasonally Adjusted                Data Updated: 2026-06-05
DGS10                Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-06-15
                     Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
DGS3                 Market Yield on U.S. Treasury Securities at 3-Year Constant Maturity,   Data Updated: 2026-06-15
                     Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
PPAAUS00000A156NCEN  Estimated Percent of People of All Ages in Poverty for United States,   Data Updated: 2026-02-09
                     Percent, Annual, Not Seasonally Adjusted
-------------------  ----------------------------------------------------------------------  ------------------------

